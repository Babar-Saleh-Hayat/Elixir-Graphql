ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Sntx.Repo, :manual)
