[
  import_deps: [:ecto_sql],
  inputs: ["*.exs"],
  line_length: 120
]
