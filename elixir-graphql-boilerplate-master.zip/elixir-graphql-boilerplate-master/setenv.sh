#!/usr/bin/env bash

set -o allexport
source ./.env.local
set +o allexport
