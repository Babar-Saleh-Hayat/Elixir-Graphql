import EctoEnum

defenum(UserAccountRole, :user_role, [
  :user,
  :administrator
])
